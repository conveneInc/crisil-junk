(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/dashboard/dashboard.component */ "./src/app/components/dashboard/dashboard.component.ts");




var routes = [
    { path: 'dashboard', component: _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__["DashboardComponent"] }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var angular_font_awesome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! angular-font-awesome */ "./node_modules/angular-font-awesome/dist/angular-font-awesome.es5.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/dashboard/dashboard.component */ "./src/app/components/dashboard/dashboard.component.ts");
/* harmony import */ var ngx_bootstrap_tabs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-bootstrap/tabs */ "./node_modules/ngx-bootstrap/tabs/fesm5/ngx-bootstrap-tabs.js");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/header/header.component */ "./src/app/components/header/header.component.ts");
/* harmony import */ var _services_interceptor_config__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./services/interceptor.config */ "./src/app/services/interceptor.config.ts");
/* harmony import */ var _services_settings_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./services/settings.service */ "./src/app/services/settings.service.ts");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _services_user_impl_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./services/user.impl.service */ "./src/app/services/user.impl.service.ts");
/* harmony import */ var _services_dashboard_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./services/dashboard.service */ "./src/app/services/dashboard.service.ts");


















var routes = [
    { path: 'dashboard', component: _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_9__["DashboardComponent"] },
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    { path: '**', redirectTo: 'dashboard' }
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"],
                _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_9__["DashboardComponent"],
                _components_header_header_component__WEBPACK_IMPORTED_MODULE_12__["HeaderComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { useHash: true }),
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"],
                ngx_bootstrap_tabs__WEBPACK_IMPORTED_MODULE_10__["TabsModule"].forRoot(),
                ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_11__["ModalModule"].forRoot(),
                angular_font_awesome__WEBPACK_IMPORTED_MODULE_6__["AngularFontAwesomeModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"]
            ],
            providers: [
                _services_user_service__WEBPACK_IMPORTED_MODULE_15__["UserService"],
                _services_user_impl_service__WEBPACK_IMPORTED_MODULE_16__["UserImpl"],
                _services_settings_service__WEBPACK_IMPORTED_MODULE_14__["SettingsService"],
                _services_dashboard_service__WEBPACK_IMPORTED_MODULE_17__["DashboardService"],
                { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HTTP_INTERCEPTORS"], useClass: _services_interceptor_config__WEBPACK_IMPORTED_MODULE_13__["InterceptorConfig"], multi: true }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.html":
/*!***************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-body\">\r\n  <div class=\"container\">\r\n      <div class=\"top-sec\">\r\n          <h1>All Mandates</h1>\r\n\r\n          <div class=\"btn-to-right \">\r\n              <button type=\"button\" class=\"btn red-btn\" (click)=\"openModal(newMandate )\">New Mandate </button>\r\n              <button type=\"button\" class=\"btn btn-default grey-btn\" (click)=\"openModal(bulkMandate)\">Bulk\r\n                  Mandate</button></div>\r\n\r\n          <ng-template #newMandate>\r\n              <div class=\"modal-header\">\r\n                  <h5 class=\"h5-heading pull-left\">New Mandate</h5>\r\n                  <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"modalRef.hide()\">\r\n                      <span aria-hidden=\"true\">&times;</span>\r\n                  </button>\r\n              </div>\r\n              <div class=\"modal-body\">\r\n                  <form>\r\n                      <p>To Create New mandate you need to Select the</p>\r\n                      <div class=\"form-group\">\r\n                          <label for=\"exampleFormControlSelect1\">Product type </label>\r\n                          <select class=\"form-control\" id=\"exampleFormControlSelect1\">\r\n                              <option>1</option>\r\n                              <option>2</option>\r\n                              <option>3</option>\r\n                              <option>4</option>\r\n                              <option>5</option>\r\n                          </select>\r\n                      </div>\r\n                      <div class=\"form-group\">\r\n                          <label for=\"exampleFormControlSelect2\">Institution</label>\r\n                          <select class=\"form-control\" id=\"exampleFormControlSelect1\">\r\n                              <option>1</option>\r\n                              <option>2</option>\r\n                              <option>3</option>\r\n                              <option>4</option>\r\n                              <option>5</option>\r\n                          </select>\r\n                      </div>\r\n                  </form>\r\n                  <div class=\"float-right button-footer\">\r\n                      <button type=\"button\" class=\"btn btn-primary btn-small-grey\">Cancel</button>\r\n                      <button type=\"button\" class=\"btn btn-secondary btn-small-dark-grey\">Apply </button>\r\n                  </div>\r\n              </div>\r\n          </ng-template>\r\n\r\n\r\n          <ng-template #bulkMandate>\r\n              <div class=\"modal-header\">\r\n                  <h4 class=\"modal-title pull-left\">Bulk Mandate</h4>\r\n                  <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"modalRef.hide()\">\r\n                      <span aria-hidden=\"true\">&times;</span>\r\n                  </button>\r\n              </div>\r\n              <div class=\"modal-body\">\r\n                  <form>\r\n                      <p>To Create New mandate you need to Select the</p>\r\n                      <div class=\"form-group\">\r\n                          <label for=\"exampleFormControlSelect1\">Product type </label>\r\n                          <select class=\"form-control\" id=\"exampleFormControlSelect1\">\r\n                              <option>1</option>\r\n                              <option>2</option>\r\n                              <option>3</option>\r\n                              <option>4</option>\r\n                              <option>5</option>\r\n                          </select>\r\n                      </div>\r\n                      <div class=\"form-group\">\r\n                          <label for=\"exampleFormControlSelect2\">Institution</label>\r\n                          <select class=\"form-control\" id=\"exampleFormControlSelect1\">\r\n                              <option>1</option>\r\n                              <option>2</option>\r\n                              <option>3</option>\r\n                              <option>4</option>\r\n                              <option>5</option>\r\n                          </select>\r\n                      </div>\r\n                  </form>\r\n                  <div class=\"float-right button-footer\">\r\n                      <button type=\"button\" class=\"btn btn-primary btn-small-grey\">Cancel</button>\r\n                      <button type=\"button\" class=\"btn btn-secondary btn-small-dark-grey\">Apply </button>\r\n                  </div>\r\n              </div>\r\n          </ng-template>\r\n\r\n      </div>\r\n\r\n      <tabset class=\"tabs-main-table\" #tabset>\r\n          <tab customClass=\"customClass\" heading=\"2000 Mandates\">\r\n             <div class=\"right-export\">\r\n                  <div class=\"dataTables_length float-left\" id=\"datable_1_length\"><label>No of Rows</label> <select name=\"datable_1_length\" aria-controls=\"datable_1\" class=\"\"><option value=\"10\">10</option><option value=\"25\">25</option><option value=\"50\">50</option><option value=\"100\">100</option></select> </div>\r\n              <ul class=\"nav float-right\">\r\n                  <li><a href=\"\">Export to Excel</a></li>\r\n                  <li><a href=\"\">Delete</a></li>\r\n                  <li><a href=\"\">Archive to Excel</a></li>\r\n                  <li><a href=\"\">Configure Columns</a></li>\r\n              </ul>\r\n              </div>\r\n              <div class=\"table-main\">\r\n                      <div class=\"table-scrollcontainer\">\r\n                          <table class=\"table\">\r\n\r\n                                  <tr class=\"th-border-custom\">\r\n                            <th class=\"table-fixedcolumn th-border-custom \">\r\n                                  <input type=\"checkbox\" class=\"form-check-input\">\r\n                                          </th>\r\n                              <th class=\"table-fixedcolumn-mandate-ID th-border-custom \">\r\n                                              Entity name\r\n                                              <i class=\"fa fa-sort\" aria-hidden=\"true\"></i></th>\r\n                              <th class=\"table-fixedcolumn-entity-name th-border-custom \">\r\n                                            Institution Name\r\n                                            <i class=\"fa fa-sort\" aria-hidden=\"true\"></i> </th>\r\n                                          <th>\r\n                                            BD\r\n                                            <i class=\"fa fa-sort\" aria-hidden=\"true\"></i> </th>\r\n                                          <th>\r\n                                          Case login date\r\n                                          <i class=\"fa fa-sort\" aria-hidden=\"true\"></i>\r\n                                          <i class=\"fa fa-filter\"></i></th>\r\n                                          <th>\r\n                                            Main STatus\r\n                                            <i class=\"fa fa-sort\" aria-hidden=\"true\"></i>\r\n                                            <i class=\"fa fa-filter\"></i></th>\r\n                                          <th>\r\n                                            Sub STatus\r\n                                            <i class=\"fa fa-sort\" aria-hidden=\"true\"></i>\r\n                                            <i class=\"fa fa-filter\"></i></th>\r\n                                          <th>\r\n                                           Coordi\r\n                                           <i class=\"fa fa-sort\" aria-hidden=\"true\"></i> </th>\r\n                                          <th>\r\n                                            Coordi\r\n                                            <i class=\"fa fa-sort\" aria-hidden=\"true\"></i> </th>\r\n                                          <th>\r\n                                              Look\r\n                                              <i class=\"fa fa-sort\" aria-hidden=\"true\"></i></th>\r\n                                              <th>\r\n                                                      Look\r\n                                                      <i class=\"fa fa-sort\" aria-hidden=\"true\"></i></th>\r\n\r\n                                      </tr>\r\n\r\n\r\n                              <tr>\r\n                                  <td class=\"table-fixedcolumn\">\r\n                                          <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                  </td>\r\n                                  <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                      589230436-1\r\n                                  </td>\r\n                                  <td class=\"table-fixedcolumn-entity-name\">\r\n                                   Atria Power Corporation Private LImited\r\n                                  </td>\r\n                                  <td >\r\n                                    Genco\r\n                                  </td>\r\n                                  <td >\r\n                                    Darius Cummings\r\n                                  </td>\r\n                                  <td >\r\n                                   05/01/2017\r\n                                  </td>\r\n                                  <td >\r\n                                   Mandate Created\r\n                                  </td>\r\n                                  <td >\r\n                                    Sub status\r\n                                  </td>\r\n                                  <td>\r\n                                   Sub status\r\n                                  </td>\r\n                                  <td>\r\n                                  Sub status\r\n                                  </td>\r\n                                   <td>\r\n                                     Sub status\r\n                                   </td>\r\n                              </tr>\r\n                              <tr>\r\n                                      <td class=\"table-fixedcolumn\">\r\n                                              <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                      </td>\r\n                                      <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                          589230436-1\r\n                                      </td>\r\n                                      <td class=\"table-fixedcolumn-entity-name\">\r\n                                       Atria Power Corporation Private LImited\r\n                                      </td>\r\n                                      <td >\r\n                                        Genco\r\n                                      </td>\r\n                                      <td >\r\n                                        Darius Cummings\r\n                                      </td>\r\n                                      <td >\r\n                                       05/01/2017\r\n                                      </td>\r\n                                      <td >\r\n                                       Mandate Created\r\n                                      </td>\r\n                                      <td >\r\n                                        Sub status\r\n                                      </td>\r\n                                      <td>\r\n                                       Sub status\r\n                                      </td>\r\n                                      <td>\r\n                                      Sub status\r\n                                      </td>\r\n                                       <td>\r\n                                         Sub status\r\n                                       </td>\r\n                                  </tr>\r\n                                  <tr>\r\n                                          <td class=\"table-fixedcolumn\">\r\n                                                  <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                          </td>\r\n                                          <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                              589230436-1\r\n                                          </td>\r\n                                          <td class=\"table-fixedcolumn-entity-name\">\r\n                                           Atria Power Corporation Private LImited\r\n                                          </td>\r\n                                          <td >\r\n                                            Genco\r\n                                          </td>\r\n                                          <td >\r\n                                            Darius Cummings\r\n                                          </td>\r\n                                          <td >\r\n                                           05/01/2017\r\n                                          </td>\r\n                                          <td >\r\n                                           Mandate Created\r\n                                          </td>\r\n                                          <td >\r\n                                            Sub status\r\n                                          </td>\r\n                                          <td>\r\n                                           Sub status\r\n                                          </td>\r\n                                          <td>\r\n                                          Sub status\r\n                                          </td>\r\n                                           <td>\r\n                                             Sub status\r\n                                           </td>\r\n                                      </tr>\r\n\r\n                                      <tr>\r\n                                              <td class=\"table-fixedcolumn\">\r\n                                                      <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                              </td>\r\n                                              <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                                  589230436-1\r\n                                              </td>\r\n                                              <td class=\"table-fixedcolumn-entity-name\">\r\n                                               Atria Power Corporation Private LImited\r\n                                              </td>\r\n                                              <td >\r\n                                                Genco\r\n                                              </td>\r\n                                              <td >\r\n                                                Darius Cummings\r\n                                              </td>\r\n                                              <td >\r\n                                               05/01/2017\r\n                                              </td>\r\n                                              <td >\r\n                                               Mandate Created\r\n                                              </td>\r\n                                              <td >\r\n                                                Sub status\r\n                                              </td>\r\n                                              <td>\r\n                                               Sub status\r\n                                              </td>\r\n                                              <td>\r\n                                              Sub status\r\n                                              </td>\r\n                                               <td>\r\n                                                 Sub status\r\n                                               </td>\r\n                                          </tr>\r\n\r\n\r\n                                          <tr>\r\n                                                  <td class=\"table-fixedcolumn\">\r\n                                                          <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                                  </td>\r\n                                                  <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                                      589230436-1\r\n                                                  </td>\r\n                                                  <td class=\"table-fixedcolumn-entity-name\">\r\n                                                   Atria Power Corporation Private LImited\r\n                                                  </td>\r\n                                                  <td >\r\n                                                    Genco\r\n                                                  </td>\r\n                                                  <td >\r\n                                                    Darius Cummings\r\n                                                  </td>\r\n                                                  <td >\r\n                                                   05/01/2017\r\n                                                  </td>\r\n                                                  <td >\r\n                                                   Mandate Created\r\n                                                  </td>\r\n                                                  <td >\r\n                                                    Sub status\r\n                                                  </td>\r\n                                                  <td>\r\n                                                   Sub status\r\n                                                  </td>\r\n                                                  <td>\r\n                                                  Sub status\r\n                                                  </td>\r\n                                                   <td>\r\n                                                     Sub status\r\n                                                   </td>\r\n                                              </tr>\r\n\r\n                                              <tr>\r\n                                                      <td class=\"table-fixedcolumn\">\r\n                                                              <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                                      </td>\r\n                                                      <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                                          589230436-1\r\n                                                      </td>\r\n                                                      <td class=\"table-fixedcolumn-entity-name\">\r\n                                                       Atria Power Corporation Private LImited\r\n                                                      </td>\r\n                                                      <td >\r\n                                                        Genco\r\n                                                      </td>\r\n                                                      <td >\r\n                                                        Darius Cummings\r\n                                                      </td>\r\n                                                      <td >\r\n                                                       05/01/2017\r\n                                                      </td>\r\n                                                      <td >\r\n                                                       Mandate Created\r\n                                                      </td>\r\n                                                      <td >\r\n                                                        Sub status\r\n                                                      </td>\r\n                                                      <td>\r\n                                                       Sub status\r\n                                                      </td>\r\n                                                      <td>\r\n                                                      Sub status\r\n                                                      </td>\r\n                                                       <td>\r\n                                                         Sub status\r\n                                                       </td>\r\n                                                  </tr>\r\n\r\n                                                  <tr>\r\n                                                          <td class=\"table-fixedcolumn\">\r\n                                                                  <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                                          </td>\r\n                                                          <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                                              589230436-1\r\n                                                          </td>\r\n                                                          <td class=\"table-fixedcolumn-entity-name\">\r\n                                                           Atria Power Corporation Private LImited\r\n                                                          </td>\r\n                                                          <td >\r\n                                                            Genco\r\n                                                          </td>\r\n                                                          <td >\r\n                                                            Darius Cummings\r\n                                                          </td>\r\n                                                          <td >\r\n                                                           05/01/2017\r\n                                                          </td>\r\n                                                          <td >\r\n                                                           Mandate Created\r\n                                                          </td>\r\n                                                          <td >\r\n                                                            Sub status\r\n                                                          </td>\r\n                                                          <td>\r\n                                                           Sub status\r\n                                                          </td>\r\n                                                          <td>\r\n                                                          Sub status\r\n                                                          </td>\r\n                                                           <td>\r\n                                                             Sub status\r\n                                                           </td>\r\n                                                      </tr>\r\n\r\n                                                      <tr>\r\n                                                              <td class=\"table-fixedcolumn\">\r\n                                                                      <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                                              </td>\r\n                                                              <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                                                  589230436-1\r\n                                                              </td>\r\n                                                              <td class=\"table-fixedcolumn-entity-name\">\r\n                                                               Atria Power Corporation Private LImited\r\n                                                              </td>\r\n                                                              <td >\r\n                                                                Genco\r\n                                                              </td>\r\n                                                              <td >\r\n                                                                Darius Cummings\r\n                                                              </td>\r\n                                                              <td >\r\n                                                               05/01/2017\r\n                                                              </td>\r\n                                                              <td >\r\n                                                               Mandate Created\r\n                                                              </td>\r\n                                                              <td >\r\n                                                                Sub status\r\n                                                              </td>\r\n                                                              <td>\r\n                                                               Sub status\r\n                                                              </td>\r\n                                                              <td>\r\n                                                              Sub status\r\n                                                              </td>\r\n                                                               <td>\r\n                                                                 Sub status\r\n                                                               </td>\r\n                                                          </tr>\r\n                                                          <tr>\r\n                                                                  <td class=\"table-fixedcolumn\">\r\n                                                                          <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                                                  </td>\r\n                                                                  <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                                                      589230436-1\r\n                                                                  </td>\r\n                                                                  <td class=\"table-fixedcolumn-entity-name\">\r\n                                                                   Atria Power Corporation Private LImited\r\n                                                                  </td>\r\n                                                                  <td >\r\n                                                                    Genco\r\n                                                                  </td>\r\n                                                                  <td >\r\n                                                                    Darius Cummings\r\n                                                                  </td>\r\n                                                                  <td >\r\n                                                                   05/01/2017\r\n                                                                  </td>\r\n                                                                  <td >\r\n                                                                   Mandate Created\r\n                                                                  </td>\r\n                                                                  <td >\r\n                                                                    Sub status\r\n                                                                  </td>\r\n                                                                  <td>\r\n                                                                   Sub status\r\n                                                                  </td>\r\n                                                                  <td>\r\n                                                                  Sub status\r\n                                                                  </td>\r\n                                                                   <td>\r\n                                                                     Sub status\r\n                                                                   </td>\r\n                                                              </tr>\r\n\r\n                                                              <tr>\r\n                                                                      <td class=\"table-fixedcolumn\">\r\n                                                                              <input type=\"checkbox\" class=\"form-check-input\" id=\"exampleCheck1\">\r\n                                                                      </td>\r\n                                                                      <td class=\"table-fixedcolumn-mandate-ID\">\r\n                                                                          589230436-1\r\n                                                                      </td>\r\n                                                                      <td class=\"table-fixedcolumn-entity-name\">\r\n                                                                       Atria Power Corporation Private LImited\r\n                                                                      </td>\r\n                                                                      <td >\r\n                                                                        Genco\r\n                                                                      </td>\r\n                                                                      <td >\r\n                                                                        Darius Cummings\r\n                                                                      </td>\r\n                                                                      <td >\r\n                                                                       05/01/2017\r\n                                                                      </td>\r\n                                                                      <td >\r\n                                                                       Mandate Created\r\n                                                                      </td>\r\n                                                                      <td >\r\n                                                                        Sub status\r\n                                                                      </td>\r\n                                                                      <td>\r\n                                                                       Sub status\r\n                                                                      </td>\r\n                                                                      <td>\r\n                                                                      Sub status\r\n                                                                      </td>\r\n                                                                       <td>\r\n                                                                         Sub status\r\n                                                                       </td>\r\n                                                                  </tr>\r\n                          </table>\r\n                      </div>\r\n                  </div>\r\n\r\n                  <div class=\"pagenation\">\r\n                      <div class=\"row\">\r\n                          <div class=\"col-sm-4\"><span>50 Mandates</span></div>\r\n                          <div class=\"col-sm-4\">\r\n                                  <ul class=\"pagination \">\r\n                                          <li class=\"disabled\"><a href=\"#\"><i class=\"fa fa-angle-left\"></i></a></li>\r\n                                          <li class=\"active\"><a href=\"#\">1 <span class=\"sr-only\">(current)</span></a></li>\r\n                                          <li><a href=\"#\">2</a></li>\r\n                                          <li><a href=\"#\">3</a></li>\r\n                                          <li><a class=\"active\" href=\"#\">4</a></li>\r\n                                          <li><a href=\"#\">5</a></li>\r\n                                          <li><a href=\"#\"><i class=\"fa fa-angle-right\"></i></a></li>\r\n                                        </ul>\r\n\r\n                          </div>\r\n                          <div class=\"col-sm-4\">\r\n                                  <div class=\"form-group \">\r\n                                          <label for=\"inputEmail3\" class=\"col-form-label\">Go to page:</label>\r\n                                          <div class=\"col-sm-2\">\r\n                                            <input type=\"email\" class=\"form-control\"  placeholder=\"10\">\r\n                                          </div>\r\n                                        </div>\r\n\r\n                          </div>\r\n\r\n\r\n                      </div>\r\n\r\n\r\n\r\n                  </div>\r\n\r\n          </tab>\r\n\r\n          <tab heading=\"800\r\n            Mandates Created \">\r\n\r\n\r\n          </tab>\r\n\r\n          <tab heading=\"500\r\n            originated\">Tab 3 content</tab>\r\n\r\n          <tab heading=\"400\r\n            Rejected\">Tab 4 content</tab>\r\n\r\n          <tab heading=\"3000\r\n            Rejected\">Gradings Provided</tab>\r\n      </tabset>\r\n\r\n  </div>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".right-export {\n  clear: both;\n  display: block;\n  overflow: hidden;\n  padding: 20px 20px 30px 20px; }\n\n.right-export ul li a {\n  color: #498FFF;\n  font-size: 14px;\n  border-right: 1px solid #707070;\n  padding: 0px 8px; }\n\n.right-export ul li {\n  padding: 0px; }\n\n.right-export ul li:first-child a, .right-export ul li:nth-child(2) a {\n  color: #ccc; }\n\n.right-export ul li:last-child a {\n  border-right: none; }\n\ni.fa.fa-filter {\n  text-align: right;\n  margin-left: 12px; }\n\n.table-scrollcontainer {\n  width: 100%;\n  overflow-x: scroll;\n  margin-left: 30em;\n  overflow-y: visible;\n  max-width: 730px; }\n\n.table-fixedcolumn {\n  position: absolute;\n  left: 0;\n  top: auto;\n  padding: 13px 28px 29px 28px;\n  width: 5em; }\n\n.table-fixedcolumn-mandate-ID {\n  position: absolute;\n  width: 10em;\n  left: 4em;\n  top: auto; }\n\n.table-fixedcolumn-entity-name {\n  position: absolute;\n  width: 339px;\n  left: 12em;\n  top: auto;\n  white-space: nowrap; }\n\n.table th, .table td, .table td, .table th {\n  border: none; }\n\n.table th, .table td {\n  white-space: nowrap; }\n\n.th-border-custom {\n  border-bottom: 1px solid #D1D1D1 !important; }\n\n.table-main {\n  position: relative;\n  margin: 0px 10px; }\n\n.table th {\n  color: #000;\n  font-size: 12px;\n  text-transform: uppercase; }\n\n.table td {\n  font-size: 14px;\n  color: #B4B4B4; }\n\ntd.table-fixedcolumn-entity-name {\n  color: #498FFF !important;\n  border-right: 1px solid #ccc !important;\n  width: 313px; }\n\n.pagenation ul li a {\n  color: #595959;\n  padding: 0px 8px;\n  font-size: 16px; }\n\n.pagenation ul li a.active {\n  color: #fff;\n  background: #D8002A;\n  width: 20px;\n  height: 20px;\n  border-radius: 20px;\n  padding: 1px 7px; }\n\n.pagenation ul li a .fa-angle-left, .fa-angle-right {\n  color: #4D4D4D;\n  font-size: 24px;\n  margin-top: 0px; }\n\n.pagenation {\n  text-align: center;\n  padding: 20px 0px; }\n\n.dataTables_length {\n  border: 1px solid #707070; }\n\n.dataTables_length label {\n  background: #f3f3f3;\n  margin-bottom: 0px;\n  color: #B4B4B4;\n  padding: 2px 5px;\n  line-height: inherit;\n  font-size: 14px; }\n\n.dataTables_length select {\n  border: none; }\n\n@media (min-width: 1439px) {\n  .table-scrollcontainer {\n    width: 100%;\n    max-width: 890px; } }\n\n:host > > > .customClass > a {\n  color: red !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9kYXNoYm9hcmQvRDpcXHdvcmtcXGNyaXNpbC9zcmNcXGFwcFxcY29tcG9uZW50c1xcZGFzaGJvYXJkXFxkYXNoYm9hcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFXO0VBQ1gsY0FBYztFQUNkLGdCQUFnQjtFQUNoQiw0QkFBNEIsRUFBQTs7QUFFOUI7RUFDQSxjQUFjO0VBQ2QsZUFBZTtFQUNmLCtCQUErQjtFQUMvQixnQkFBZ0IsRUFBQTs7QUFFaEI7RUFDQSxZQUFhLEVBQUE7O0FBRWI7RUFDRSxXQUFXLEVBQUE7O0FBRWI7RUFDRSxrQkFBa0IsRUFBQTs7QUFFcEI7RUFDRSxpQkFBaUI7RUFDakIsaUJBQWlCLEVBQUE7O0FBR25CO0VBQ0UsV0FBVTtFQUNYLGtCQUFpQjtFQUNoQixpQkFBZ0I7RUFDaEIsbUJBQWtCO0VBQ2xCLGdCQUFnQixFQUFBOztBQUVsQjtFQUNFLGtCQUFrQjtFQUNsQixPQUFPO0VBQ1AsU0FBUztFQUNULDRCQUE0QjtFQUM1QixVQUFVLEVBQUE7O0FBRVo7RUFDRSxrQkFBaUI7RUFDakIsV0FBVztFQUNYLFNBQVE7RUFDUixTQUFRLEVBQUE7O0FBRVY7RUFDRSxrQkFBaUI7RUFDakIsWUFBWTtFQUNaLFVBQVM7RUFDVCxTQUFRO0VBQ1IsbUJBQW1CLEVBQUE7O0FBR3JCO0VBQ0UsWUFBWSxFQUFBOztBQUVkO0VBQ0UsbUJBQW1CLEVBQUE7O0FBRXJCO0VBQ0EsMkNBQTBDLEVBQUE7O0FBRzFDO0VBQ0Usa0JBQWtCO0VBQ2xCLGdCQUFnQixFQUFBOztBQUdsQjtFQUNBLFdBQVU7RUFDVixlQUFlO0VBQ2YseUJBQXlCLEVBQUE7O0FBSXpCO0VBQ0UsZUFBZTtFQUNmLGNBQWMsRUFBQTs7QUFHaEI7RUFDRSx5QkFBd0I7RUFDeEIsdUNBQXVDO0VBQ3ZDLFlBQVksRUFBQTs7QUFFZDtFQUNFLGNBQWE7RUFDYixnQkFBZ0I7RUFDaEIsZUFBZSxFQUFBOztBQUdqQjtFQUNBLFdBQVU7RUFDVixtQkFBa0I7RUFDbEIsV0FBVztFQUNYLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsZ0JBQWdCLEVBQUE7O0FBR2hCO0VBQ0EsY0FBYTtFQUNiLGVBQWU7RUFDZixlQUFlLEVBQUE7O0FBRWY7RUFDRSxrQkFBa0I7RUFDbEIsaUJBQWlCLEVBQUE7O0FBRW5CO0VBQ0EseUJBQXlCLEVBQUE7O0FBRXpCO0VBQ0UsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixlQUFlLEVBQUE7O0FBR2pCO0VBQ0EsWUFBWSxFQUFBOztBQUVaO0VBQ0U7SUFDRSxXQUFXO0lBQ1gsZ0JBQWdCLEVBQUEsRUFFbkI7O0FBR0Q7RUFDRSxxQkFBcUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvZGFzaGJvYXJkL2Rhc2hib2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yaWdodC1leHBvcnQge1xyXG4gIGNsZWFyOiBib3RoO1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgcGFkZGluZzogMjBweCAyMHB4IDMwcHggMjBweDtcclxufVxyXG4ucmlnaHQtZXhwb3J0IHVsIGxpIGEge1xyXG5jb2xvcjogIzQ5OEZGRjtcclxuZm9udC1zaXplOiAxNHB4O1xyXG5ib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjNzA3MDcwO1xyXG5wYWRkaW5nOiAwcHggOHB4O1xyXG59XHJcbi5yaWdodC1leHBvcnQgdWwgbGkge1xyXG5wYWRkaW5nOiAwcHggO1xyXG59XHJcbi5yaWdodC1leHBvcnQgdWwgbGk6Zmlyc3QtY2hpbGQgYSwgLnJpZ2h0LWV4cG9ydCB1bCBsaTpudGgtY2hpbGQoMikgYXtcclxuICBjb2xvcjogI2NjYztcclxufVxyXG4ucmlnaHQtZXhwb3J0IHVsIGxpOmxhc3QtY2hpbGQgYSB7XHJcbiAgYm9yZGVyLXJpZ2h0OiBub25lO1xyXG59XHJcbmkuZmEuZmEtZmlsdGVyIHtcclxuICB0ZXh0LWFsaWduOiByaWdodDtcclxuICBtYXJnaW4tbGVmdDogMTJweDtcclxufVxyXG5cclxuLnRhYmxlLXNjcm9sbGNvbnRhaW5lciB7XHJcbiAgd2lkdGg6MTAwJTtcclxuIG92ZXJmbG93LXg6c2Nyb2xsO1xyXG4gIG1hcmdpbi1sZWZ0OjMwZW07XHJcbiAgb3ZlcmZsb3cteTp2aXNpYmxlO1xyXG4gIG1heC13aWR0aDogNzMwcHg7XHJcbn1cclxuLnRhYmxlLWZpeGVkY29sdW1uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgbGVmdDogMDtcclxuICB0b3A6IGF1dG87XHJcbiAgcGFkZGluZzogMTNweCAyOHB4IDI5cHggMjhweDtcclxuICB3aWR0aDogNWVtO1xyXG59XHJcbi50YWJsZS1maXhlZGNvbHVtbi1tYW5kYXRlLUlEIHtcclxuICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICB3aWR0aDogMTBlbTtcclxuICBsZWZ0OjRlbTtcclxuICB0b3A6YXV0bztcclxufVxyXG4udGFibGUtZml4ZWRjb2x1bW4tZW50aXR5LW5hbWV7XHJcbiAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgd2lkdGg6IDMzOXB4O1xyXG4gIGxlZnQ6MTJlbTtcclxuICB0b3A6YXV0bztcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG59XHJcblxyXG4udGFibGUgdGgsIC50YWJsZSB0ZCwgLnRhYmxlIHRkLCAudGFibGUgdGgge1xyXG4gIGJvcmRlcjogbm9uZTtcclxufVxyXG4udGFibGUgdGgsIC50YWJsZSB0ZCB7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxufVxyXG4udGgtYm9yZGVyLWN1c3RvbSB7XHJcbmJvcmRlci1ib3R0b206MXB4IHNvbGlkICNEMUQxRDEgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnRhYmxlLW1haW4ge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBtYXJnaW46IDBweCAxMHB4O1xyXG59XHJcblxyXG4udGFibGUgdGh7XHJcbmNvbG9yOiMwMDA7XHJcbmZvbnQtc2l6ZTogMTJweDtcclxudGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufVxyXG5cclxuXHJcbi50YWJsZSB0ZCB7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGNvbG9yOiAjQjRCNEI0O1xyXG59XHJcblxyXG50ZC50YWJsZS1maXhlZGNvbHVtbi1lbnRpdHktbmFtZSB7XHJcbiAgY29sb3I6IzQ5OEZGRiAhaW1wb3J0YW50O1xyXG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNjY2MgIWltcG9ydGFudDtcclxuICB3aWR0aDogMzEzcHg7XHJcbn1cclxuLnBhZ2VuYXRpb24gdWwgbGkgYSB7XHJcbiAgY29sb3I6IzU5NTk1OTtcclxuICBwYWRkaW5nOiAwcHggOHB4O1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuXHJcbn1cclxuLnBhZ2VuYXRpb24gdWwgbGkgYS5hY3RpdmUge1xyXG5jb2xvcjojZmZmO1xyXG5iYWNrZ3JvdW5kOiNEODAwMkE7XHJcbndpZHRoOiAyMHB4O1xyXG5oZWlnaHQ6IDIwcHg7XHJcbmJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbnBhZGRpbmc6IDFweCA3cHg7XHJcblxyXG59XHJcbi5wYWdlbmF0aW9uIHVsIGxpIGEgLmZhLWFuZ2xlLWxlZnQsIC5mYS1hbmdsZS1yaWdodCAge1xyXG5jb2xvcjojNEQ0RDREO1xyXG5mb250LXNpemU6IDI0cHg7XHJcbm1hcmdpbi10b3A6IDBweDtcclxufVxyXG4ucGFnZW5hdGlvbiB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHBhZGRpbmc6IDIwcHggMHB4O1xyXG59XHJcbi5kYXRhVGFibGVzX2xlbmd0aCB7XHJcbmJvcmRlcjogMXB4IHNvbGlkICM3MDcwNzA7XHJcbn1cclxuLmRhdGFUYWJsZXNfbGVuZ3RoIGxhYmVsIHtcclxuICBiYWNrZ3JvdW5kOiAjZjNmM2YzO1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBjb2xvcjogI0I0QjRCNDtcclxuICBwYWRkaW5nOiAycHggNXB4O1xyXG4gIGxpbmUtaGVpZ2h0OiBpbmhlcml0O1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuXHJcbn1cclxuLmRhdGFUYWJsZXNfbGVuZ3RoIHNlbGVjdCAge1xyXG5ib3JkZXI6IG5vbmU7XHJcbn1cclxuQG1lZGlhIChtaW4td2lkdGg6MTQzOXB4KSB7XHJcbiAgLnRhYmxlLXNjcm9sbGNvbnRhaW5lciB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1heC13aWR0aDogODkwcHg7XHJcblxyXG59XHJcblxyXG59XHJcbjpob3N0ID4+PiAuY3VzdG9tQ2xhc3MgPiBhe1xyXG4gIGNvbG9yOiByZWQgIWltcG9ydGFudDtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.ts ***!
  \*************************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var _services_settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/settings.service */ "./src/app/services/settings.service.ts");




var DashboardComponent = /** @class */ (function () {
    function DashboardComponent(modalService, settingsService) {
        this.modalService = modalService;
        this.settingsService = settingsService;
        this.title = 'Crisil Dashboard';
    }
    DashboardComponent.prototype.openModal = function (bulkMandate) {
        this.modalRef = this.modalService.show(bulkMandate, {});
    };
    DashboardComponent.prototype.getLabels = function () {
        return this.settingsService.getUiLabels();
    };
    DashboardComponent.prototype.ngOnInit = function () {
    };
    DashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__(/*! ./dashboard.component.html */ "./src/app/components/dashboard/dashboard.component.html"),
            styles: [__webpack_require__(/*! ./dashboard.component.scss */ "./src/app/components/dashboard/dashboard.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_2__["BsModalService"], _services_settings_service__WEBPACK_IMPORTED_MODULE_3__["SettingsService"]])
    ], DashboardComponent);
    return DashboardComponent;
}());



/***/ }),

/***/ "./src/app/components/header/header.component.html":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header>\n  <div class=\"container\">\n    <div class=\"top-header\">\n     <div class=\"logo navbar-brand mr-0 mr-md-2\">\n       <a class=\"navbar-brand\" href=\"#\"><img src=\"assets/images/crisil-logo.png\" alt=\"logo\" title=\"Crisil logo\"/></a>\n      </div>\n      <div class=\"searchbox\">\n          <div class=\"btn-menu\">\n              <select class=\"form-control\">\n                  <option value=\"\">All</option>\n                  <option value=\"\">1</option>\n                </select>\n              </div>\n          <input id=\"search\" type=\"text\" placeholder=\"Search by ID or Institue or Entity Name\" name=\"search\" class=\"search\">\n        <button  class=\"btn-search\">\n            <i class=\"fa fa-search\"></i>\n          </button>\n      </div>\n     <div class=\"navbar-right\">\n        <ul class=\" nav \">\n          <li class=\"nav-item\"><a href=\"#\"><i class=\"fa fa-bell\" aria-hidden=\"true\"></i><span class=\"notification-num\">100</span></a></li>\n          <li class=\"nav-item\"><a href=\"#\"><i class=\"fa fa-question-circle\" aria-hidden=\"true\"></i></a></li>\n          <li class=\"nav-item\" class=\"dropdown\">\n              <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\"\n                aria-expanded=\"false\"><b>TS</b> <span class=\"caret\"></span></a>\n              <!--<ul class=\"dropdown-menu\">\n                <li ><a href=\"#\"><i class=\"fa fa-address-book-o\" aria-hidden=\"true\"></i> My account</a></li>\n                <li><a href=\"#\"><i class=\"fa fa-envelope-o fw\"></i> My inbox</a></li>\n                <li><a href=\"#\"><i class=\"fa fa-question-circle-o fw\"></i> Help</a></li>\n                <li role=\"separator\" class=\"divider\"></li>\n                <li><a href=\"#\"><i class=\"fa fa-sign-out\"></i> Log out</a></li>\n              </ul>-->\n            </li>\n        </ul>\n      </div>\n    </div>\n  </div>\n  </header>\n"

/***/ }),

/***/ "./src/app/components/header/header.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _services_settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/settings.service */ "./src/app/services/settings.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(userService, settingsService, router) {
        this.userService = userService;
        this.settingsService = settingsService;
        this.router = router;
        this.currentUser = null;
        this.errorMessage = '';
        this.isLoading = true;
    }
    HeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.loggedInUser.subscribe(function (data) {
            _this.currentUser = data;
            _this.isLoading = false;
        });
    };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/components/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.scss */ "./src/app/components/header/header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"],
            _services_settings_service__WEBPACK_IMPORTED_MODULE_3__["SettingsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/services/dashboard.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/dashboard.service.ts ***!
  \***********************************************/
/*! exports provided: DashboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardService", function() { return DashboardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var DashboardService = /** @class */ (function () {
    function DashboardService() {
    }
    DashboardService.prototype.getAllMandates = function () {
        return {};
    };
    DashboardService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
    ], DashboardService);
    return DashboardService;
}());



/***/ }),

/***/ "./src/app/services/interceptor.config.ts":
/*!************************************************!*\
  !*** ./src/app/services/interceptor.config.ts ***!
  \************************************************/
/*! exports provided: InterceptorConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InterceptorConfig", function() { return InterceptorConfig; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_user_impl_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/user.impl.service */ "./src/app/services/user.impl.service.ts");



var InterceptorConfig = /** @class */ (function () {
    function InterceptorConfig(user) {
        this.user = user;
    }
    InterceptorConfig.prototype.intercept = function (request, next) {
        if (request.method === 'POST' && this.user && this.user.getCurrentUser()) {
            console.log('from interceptor->', this.user.getCurrentUser().apiToken);
            request = request.clone({
                setHeaders: {
                    'X-Bonita-API-Token': "" + this.user.getCurrentUser().apiToken
                }
            });
        }
        return next.handle(request);
    };
    InterceptorConfig = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_user_impl_service__WEBPACK_IMPORTED_MODULE_2__["UserImpl"]])
    ], InterceptorConfig);
    return InterceptorConfig;
}());



/***/ }),

/***/ "./src/app/services/service.ts":
/*!*************************************!*\
  !*** ./src/app/services/service.ts ***!
  \*************************************/
/*! exports provided: Service, mapStatusLookups */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Service", function() { return Service; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mapStatusLookups", function() { return mapStatusLookups; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var Service = /** @class */ (function () {
    function Service() {
    }
    Service.prototype.getGetHeaders = function () {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        headers.append('Accept', 'application/json');
        return headers;
    };
    Service.prototype.getUrlHeaders = function () {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        return headers;
    };
    Service.prototype.getPostHeaders = function (userService) {
        var headers = this.getGetHeaders();
        headers.append('X-Bonita-API-Token', userService.getCurrentUser().apiToken);
        return headers;
    };
    Service = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
    ], Service);
    return Service;
}());

function mapStatusLookups(response) {
    return response.json().map(toStatusLookup);
}
function toStatusLookup(r) {
    var statusLookup = ({
        processInstanceId: r.processInstanceId,
        humanTaskStatus: r.humanTaskStatus,
        documents: r.documents.map(toDocument)
    });
    return statusLookup;
}
function toDocument(r) {
    var document = ({
        filename: r.filename,
        description: r.description,
        docId: r.docId
    });
    return document;
}


/***/ }),

/***/ "./src/app/services/settings.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/settings.service.ts ***!
  \**********************************************/
/*! exports provided: SettingsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsService", function() { return SettingsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ngx_webstorage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-webstorage-service */ "./node_modules/ngx-webstorage-service/fesm5/ngx-webstorage-service.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");






// import uiLabels from '../../assets/ui-labels.json';
var SettingsService = /** @class */ (function () {
    function SettingsService(storage, sessionStorage, http) {
        this.storage = storage;
        this.sessionStorage = sessionStorage;
        this.http = http;
        this._jsonURL = 'assets/ui-labels.json';
    }
    SettingsService.prototype.getBonitaApiBaseUrl = function () {
        // if (!this.bonitaApiBaseUrl && window && window.location) {
        //    const paths = window.location.pathname.split('/', 2);
        //    this.bonitaApiBaseUrl = window.location.origin + '/';
        //    if (paths && paths.length > 1) {
        //      this.bonitaApiBaseUrl += paths[1] ;
        //      this.bonitaApiBaseUrl += 'bonita/' ;
        //    }
        //    this.bonitaApiBaseUrl += 'API' ;
        // }
        // return this.bonitaApiBaseUrl ;
        return 'http://localhost:8080/bonita/API';
        // return 'http://localhost:9990' ;
    };
    SettingsService.prototype.getBonitaBaseUrl = function () {
        if (!this.bonitaBaseUrl && window && window.location) {
            var paths = window.location.pathname.split('/', 2);
            this.bonitaBaseUrl = '/';
            if (paths && paths.length > 1) {
                this.bonitaBaseUrl += paths[1];
            }
        }
        return this.bonitaBaseUrl;
    };
    SettingsService.prototype.getUiLabels = function () {
        if (!this.labels) {
            //   this.labels = this.getJSON();
        }
        return this.labels;
    };
    SettingsService.prototype.getJSON = function () {
        return this.http.get(this._jsonURL)
            .map(function (response) {
            response.json();
        });
    };
    SettingsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(ngx_webstorage_service__WEBPACK_IMPORTED_MODULE_3__["LOCAL_STORAGE"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(ngx_webstorage_service__WEBPACK_IMPORTED_MODULE_3__["SESSION_STORAGE"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, Object, _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], SettingsService);
    return SettingsService;
}());



/***/ }),

/***/ "./src/app/services/user.impl.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/user.impl.service.ts ***!
  \***********************************************/
/*! exports provided: UserImpl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserImpl", function() { return UserImpl; });
var UserImpl = /** @class */ (function () {
    function UserImpl() {
    }
    UserImpl.prototype.getName = function () {
        var name = null;
        if (this.firstname && this.firstname.length > 0) {
            name = this.firstname;
        }
        if (this.lastname && this.lastname.length > 0) {
            if (name) {
                name = name + ' ' + this.lastname;
            }
            else {
                name = this.lastname;
            }
        }
        if (!name || name.length === 0) {
            name = this.username;
        }
        return name;
    };
    UserImpl.prototype.setPermissions = function (permissions) {
        this.permissions = permissions;
    };
    UserImpl.prototype.getAuthorizationToken = function () {
        return this.apiToken;
    };
    UserImpl.prototype.setAuthorizationToken = function (token) {
        this.apiToken = token;
    };
    UserImpl.prototype.setCurrentUser = function (cUser) {
        this.currentUser = cUser;
    };
    UserImpl.prototype.getCurrentUser = function () {
        return this.currentUser;
    };
    return UserImpl;
}());



/***/ }),

/***/ "./src/app/services/user.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/user.service.ts ***!
  \******************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings.service */ "./src/app/services/settings.service.ts");
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./service */ "./src/app/services/service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_observable_throw__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/add/observable/throw */ "./node_modules/rxjs-compat/_esm5/add/observable/throw.js");
/* harmony import */ var _user_impl_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./user.impl.service */ "./src/app/services/user.impl.service.ts");










function mapUserList(response) {
    return response.json().map(toUser);
}
function toUser(r) {
    var user = new _user_impl_service__WEBPACK_IMPORTED_MODULE_9__["UserImpl"]();
    user.id = r.user_id;
    user.username = r.user_name;
    console.log('token => ', r.headers.get('X-Bonita-API-Token'));
    user.setAuthorizationToken(r.headers.get('X-Bonita-API-Token'));
    user.setCurrentUser(r);
    // user.firstname = r.firstname;
    // user.lastname = r.lastname;
    if (r.professional_data) {
        user.email = r.professional_data.email;
    }
    return user;
}
function mapCurrentUser(response) {
    console.log('currentUser');
    var currentUser = toCurrentUser(response);
    currentUser.apiToken = response.headers.get('X-Bonita-API-Token');
    return currentUser;
}
function handleError(err) {
    var errorMessage = '';
    if (err.error instanceof ErrorEvent) {
        errorMessage = "An error occurred: " + err.error.message;
    }
    else {
        errorMessage = "Server returned code: " + err.status + ", error message is: " + err.message;
    }
    // console.log(errorMessage);
    return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(errorMessage);
}
function toCurrentUser(r) {
    var user = new _user_impl_service__WEBPACK_IMPORTED_MODULE_9__["UserImpl"]();
    user.id = r.user_id;
    user.username = r.user_name;
    user.sessionId = r.session_id;
    return user;
}
var UserService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](UserService, _super);
    function UserService(http, settingsService) {
        var _this = _super.call(this) || this;
        _this.http = http;
        _this.settingsService = settingsService;
        _this.loggedInUser = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        var currentUser = _this.http
            .get(
        //  `${this.settingsService.getBonitaApiBaseUrl()}/loginService`,
        _this.settingsService.getBonitaApiBaseUrl() + "/system/session/unusedId", { headers: _this.getGetHeaders() })
            .map(mapCurrentUser)
            .catch(handleError);
        currentUser.subscribe(function (currentLoggedInUser) {
            // TODO: Fetching all users (c=-1) -- this is perhaps dangerous and should either grab a huge number or iterate over pages
            _this.http
                .get(_this.settingsService.getBonitaApiBaseUrl() + "/identity/user/?p=0&c=-1&d=professional_data", { headers: _this.getGetHeaders() })
                .map(mapUserList)
                .subscribe(function (userList) {
                _this.userList = new Map();
                _this.usernameList = new Map();
                for (var _i = 0, userList_1 = userList; _i < userList_1.length; _i++) {
                    var user = userList_1[_i];
                    _this.userList.set(user.id, user);
                    _this.usernameList.set(user.username, user);
                }
                _this.currentUser.apiToken = currentLoggedInUser.apiToken;
            });
        });
        return _this;
    }
    UserService.prototype.getCurrentUser = function () {
        return this.currentUser;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], UserService.prototype, "loggedInUser", void 0);
    UserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _settings_service__WEBPACK_IMPORTED_MODULE_3__["SettingsService"]])
    ], UserService);
    return UserService;
}(_service__WEBPACK_IMPORTED_MODULE_4__["Service"]));



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\work\crisil\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map