(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/dashboard/dashboard.component */ "./src/app/components/dashboard/dashboard.component.ts");




var routes = [
    { path: 'dashboard', component: _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__["DashboardComponent"] }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var angular_font_awesome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! angular-font-awesome */ "./node_modules/angular-font-awesome/dist/angular-font-awesome.es5.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/dashboard/dashboard.component */ "./src/app/components/dashboard/dashboard.component.ts");
/* harmony import */ var ngx_bootstrap_tabs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-bootstrap/tabs */ "./node_modules/ngx-bootstrap/tabs/fesm5/ngx-bootstrap-tabs.js");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/header/header.component */ "./src/app/components/header/header.component.ts");
/* harmony import */ var _services_interceptor_config__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./services/interceptor.config */ "./src/app/services/interceptor.config.ts");
/* harmony import */ var _services_settings_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./services/settings.service */ "./src/app/services/settings.service.ts");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _services_user_impl_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./services/user.impl.service */ "./src/app/services/user.impl.service.ts");

















var routes = [
    { path: 'dashboard', component: _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_9__["DashboardComponent"] },
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    { path: '**', redirectTo: 'dashboard' }
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"],
                _components_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_9__["DashboardComponent"],
                _components_header_header_component__WEBPACK_IMPORTED_MODULE_12__["HeaderComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { useHash: true }),
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"],
                ngx_bootstrap_tabs__WEBPACK_IMPORTED_MODULE_10__["TabsModule"].forRoot(),
                ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_11__["ModalModule"].forRoot(),
                angular_font_awesome__WEBPACK_IMPORTED_MODULE_6__["AngularFontAwesomeModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"]
            ],
            providers: [
                _services_user_service__WEBPACK_IMPORTED_MODULE_15__["UserService"],
                _services_user_impl_service__WEBPACK_IMPORTED_MODULE_16__["UserImpl"],
                _services_settings_service__WEBPACK_IMPORTED_MODULE_14__["SettingsService"],
                { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HTTP_INTERCEPTORS"], useClass: _services_interceptor_config__WEBPACK_IMPORTED_MODULE_13__["InterceptorConfig"], multi: true }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.html":
/*!***************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-body\">\r\n  <div class=\"container-fluid\">\r\n<div class=\"top-sec\">\r\n<h1>All Mandates</h1>\r\n\r\n<div class=\"btn-to-right \">\r\n<button type=\"button\" class=\"btn red-btn\" (click)=\"openModal(newMandate)\">New Mandate </button>\r\n<button type=\"button\" class=\"btn btn-default grey-btn\" (click)=\"openModal(bulkMandate)\">Bulk Mandate</button></div>\r\n\r\n<ng-template #newMandate>\r\n  <div class=\"modal-header\">\r\n    <h5 class=\"modal-title pull-left\">New Mandate</h5>\r\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"modalRef.hide()\">\r\n      <span aria-hidden=\"true\">&times;</span>\r\n    </button>\r\n  </div>\r\n  <div class=\"modal-body\">\r\n    <form>\r\n\r\n      <div class=\"form-group\">\r\n        <label for=\"exampleFormControlSelect1\">Product type </label>\r\n        <select class=\"form-control\" id=\"exampleFormControlSelect1\">\r\n          <option>1</option>\r\n          <option>2</option>\r\n          <option>3</option>\r\n          <option>4</option>\r\n          <option>5</option>\r\n        </select>\r\n      </div>\r\n      <div class=\"form-group\">\r\n        <label for=\"exampleFormControlSelect2\">Institution</label>\r\n        <select class=\"form-control\" id=\"exampleFormControlSelect1\">\r\n          <option>1</option>\r\n          <option>2</option>\r\n          <option>3</option>\r\n          <option>4</option>\r\n          <option>5</option>\r\n        </select>\r\n      </div>\r\n\r\n    </form>\r\n    <button type=\"button\" class=\"btn btn-primary\">Cancel</button>\r\n    <button type=\"button\" class=\"btn btn-secondary\">Apply </button>\r\n\r\n  </div>\r\n</ng-template>\r\n\r\n\r\n<ng-template #bulkMandate>\r\n  <div class=\"modal-header\">\r\n    <h4 class=\"modal-title pull-left\">Modal2</h4>\r\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"modalRef.hide()\">\r\n      <span aria-hidden=\"true\">&times;</span>\r\n    </button>\r\n  </div>\r\n  <div class=\"modal-body\">\r\n    This is a modal.\r\n  </div>\r\n</ng-template>\r\n\r\n</div>\r\n\r\n<tabset #tabset>\r\n  <tab\r\n    heading=\"2000\r\n    Mandates\"\r\n    >\r\n\r\n\r\n    <ul class=\"nav float-right\">\r\n<li><a href=\"\">Export to Excel</a></li>\r\n<li><a href=\"\">Delete</a></li>\r\n<li><a href=\"\">Archive to Excel</a></li>\r\n<li><a href=\"\">Configure Columns</a></li>\r\n    </ul>\r\n\r\n\r\n    <div class=\"limiter\">\r\n        <div class=\"container-table100\">\r\n          <div class=\"wrap-table100\">\r\n            <div class=\"table100 ver1\">\r\n              <div class=\"table100-firstcol\">\r\n                <table>\r\n                  <thead>\r\n                    <tr class=\"row100 head\">\r\n                      <th class=\"cell100 column1\">Employees</th>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody>\r\n                    <tr class=\"row100 body\">\r\n                      <td class=\"cell100 column1\">Brandon Green</td>\r\n                    </tr>\r\n\r\n                    <tr class=\"row100 body\">\r\n                      <td class=\"cell100 column1\">Kathy Daniels</td>\r\n                    </tr>\r\n\r\n                    <tr class=\"row100 body\">\r\n                      <td class=\"cell100 column1\">Elizabeth Alvarado</td>\r\n                    </tr>\r\n\r\n                    <tr class=\"row100 body\">\r\n                      <td class=\"cell100 column1\">Michael Coleman</td>\r\n                    </tr>\r\n\r\n                    <tr class=\"row100 body\">\r\n                      <td class=\"cell100 column1\">Jason Cox</td>\r\n                    </tr>\r\n\r\n                    <tr class=\"row100 body\">\r\n                      <td class=\"cell100 column1\">Christian Perkins</td>\r\n                    </tr>\r\n\r\n                    <tr class=\"row100 body\">\r\n                      <td class=\"cell100 column1\">Emily Wheeler</td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n\r\n              <div class=\"wrap-table100-nextcols js-pscroll\">\r\n                <div class=\"table100-nextcols\">\r\n                  <table>\r\n                    <thead>\r\n                      <tr class=\"row100 head\">\r\n                        <th class=\"cell100 column2\">Position</th>\r\n                        <th class=\"cell100 column3\">Start date</th>\r\n                        <th class=\"cell100 column4\">Last Activity</th>\r\n                        <th class=\"cell100 column5\">Contacts</th>\r\n                        <th class=\"cell100 column6\">Age</th>\r\n                        <th class=\"cell100 column7\">Address</th>\r\n                        <th class=\"cell100 column8\">Card No</th>\r\n                      </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                      <tr class=\"row100 body\">\r\n                        <td class=\"cell100 column2\">CMO</td>\r\n                        <td class=\"cell100 column3\">16 Nov 2012</td>\r\n                        <td class=\"cell100 column4\">16 Nov 2017</td>\r\n                        <td class=\"cell100 column5\">brandon94@example.com</td>\r\n                        <td class=\"cell100 column6\">30</td>\r\n                        <td class=\"cell100 column7\">New York City, NY</td>\r\n                        <td class=\"cell100 column8\">424242xxxxxx6262</td>\r\n                      </tr>\r\n\r\n                      <tr class=\"row100 body\">\r\n                        <td class=\"cell100 column2\">Marketing</td>\r\n                        <td class=\"cell100 column3\">16 Nov 2015</td>\r\n                        <td class=\"cell100 column4\">30 Nov 2017</td>\r\n                        <td class=\"cell100 column5\">kathy_82@example.com</td>\r\n                        <td class=\"cell100 column6\">26</td>\r\n                        <td class=\"cell100 column7\">New York City, NY</td>\r\n                        <td class=\"cell100 column8\">424242xxxxxx1616</td>\r\n                      </tr>\r\n\r\n                      <tr class=\"row100 body\">\r\n                        <td class=\"cell100 column2\">CFO</td>\r\n                        <td class=\"cell100 column3\">16 Nov 2013</td>\r\n                        <td class=\"cell100 column4\">30 Nov 2017</td>\r\n                        <td class=\"cell100 column5\">elizabeth82@example.com</td>\r\n                        <td class=\"cell100 column6\">32</td>\r\n                        <td class=\"cell100 column7\">New York City, NY</td>\r\n                        <td class=\"cell100 column8\">424242xxxxxx5326</td>\r\n                      </tr>\r\n\r\n                      <tr class=\"row100 body\">\r\n                        <td class=\"cell100 column2\">Designer</td>\r\n                        <td class=\"cell100 column3\">16 Nov 2013</td>\r\n                        <td class=\"cell100 column4\">30 Nov 2017</td>\r\n                        <td class=\"cell100 column5\">michael94@example.com</td>\r\n                        <td class=\"cell100 column6\">22</td>\r\n                        <td class=\"cell100 column7\">New York City, NY</td>\r\n                        <td class=\"cell100 column8\">424242xxxxxx6328</td>\r\n                      </tr>\r\n\r\n                      <tr class=\"row100 body\">\r\n                        <td class=\"cell100 column2\">Developer</td>\r\n                        <td class=\"cell100 column3\">16 Nov 2017</td>\r\n                        <td class=\"cell100 column4\">30 Nov 2017</td>\r\n                        <td class=\"cell100 column5\">jasoncox@example.com</td>\r\n                        <td class=\"cell100 column6\">25</td>\r\n                        <td class=\"cell100 column7\">New York City, NY</td>\r\n                        <td class=\"cell100 column8\">424242xxxxxx7648</td>\r\n                      </tr>\r\n\r\n                      <tr class=\"row100 body\">\r\n                        <td class=\"cell100 column2\">Sale</td>\r\n                        <td class=\"cell100 column3\">16 Nov 2016</td>\r\n                        <td class=\"cell100 column4\">30 Nov 2017</td>\r\n                        <td class=\"cell100 column5\">christian_83@example.com</td>\r\n                        <td class=\"cell100 column6\">28</td>\r\n                        <td class=\"cell100 column7\">New York City, NY</td>\r\n                        <td class=\"cell100 column8\">424242xxxxxx4152</td>\r\n                      </tr>\r\n\r\n                      <tr class=\"row100 body\">\r\n                        <td class=\"cell100 column2\">Support</td>\r\n                        <td class=\"cell100 column3\">16 Nov 2013</td>\r\n                        <td class=\"cell100 column4\">30 Nov 2017</td>\r\n                        <td class=\"cell100 column5\">emily90@example.com</td>\r\n                        <td class=\"cell100 column6\">24</td>\r\n                        <td class=\"cell100 column7\">New York City, NY</td>\r\n                        <td class=\"cell100 column8\">424242xxxxxx6668</td>\r\n                      </tr>\r\n                    </tbody>\r\n                  </table>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n\r\n\r\n  </tab>\r\n\r\n  <tab\r\n    heading=\"800\r\n    Mandates Created \"\r\n    >Tab 2 content</tab>\r\n\r\n      <tab\r\n    heading=\"500\r\n    originated\"\r\n    >Tab 3 content</tab>\r\n\r\n      <tab\r\n    heading=\"400\r\n    Rejected\"\r\n    >Tab 4 content</tab>\r\n\r\n    <tab\r\n    heading=\"3000\r\n    Rejected\"\r\n    >Gradings Provided</tab>\r\n</tabset>\r\n\r\n    </div>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvZGFzaGJvYXJkL2Rhc2hib2FyZC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/dashboard/dashboard.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/dashboard/dashboard.component.ts ***!
  \*************************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var _services_settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/settings.service */ "./src/app/services/settings.service.ts");




var DashboardComponent = /** @class */ (function () {
    function DashboardComponent(modalService, settingsService) {
        this.modalService = modalService;
        this.settingsService = settingsService;
        this.title = 'Crisil Dashboard';
    }
    DashboardComponent.prototype.openModal = function (bulkMandate) {
        this.modalRef = this.modalService.show(bulkMandate, {});
    };
    DashboardComponent.prototype.getLabels = function () {
        return this.settingsService.getUiLabels();
    };
    DashboardComponent.prototype.ngOnInit = function () {
    };
    DashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__(/*! ./dashboard.component.html */ "./src/app/components/dashboard/dashboard.component.html"),
            styles: [__webpack_require__(/*! ./dashboard.component.scss */ "./src/app/components/dashboard/dashboard.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_2__["BsModalService"], _services_settings_service__WEBPACK_IMPORTED_MODULE_3__["SettingsService"]])
    ], DashboardComponent);
    return DashboardComponent;
}());



/***/ }),

/***/ "./src/app/components/header/header.component.html":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header>\n  <div class=\"container-fluid\">\n     <div class=\"logo navbar-brand mr-0 mr-md-2\">\n       <a class=\"navbar-brand\" href=\"#\"><img src=\"assets/images/crisil-logo.png\" alt=\"logo\" title=\"Crisil logo\"/></a>\n      </div>\n     <div class=\"navbar-right float-right\" id=\"\">\n        <ul class=\" nav \">\n          <li class=\"nav-item\"><a href=\"#\"><i class=\"fa fa-bell\" aria-hidden=\"true\"></i><span class=\"notification-num\">100</span></a></li>\n          <li class=\"nav-item\"><a href=\"#\"><i class=\"fa fa-question-circle\" aria-hidden=\"true\"></i></a></li>\n          <li class=\"nav-item\" class=\"dropdown\">\n              <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\"\n                aria-expanded=\"false\"><b>TS</b> <span class=\"caret\"></span></a>\n              <!--<ul class=\"dropdown-menu\">\n                <li ><a href=\"#\"><i class=\"fa fa-address-book-o\" aria-hidden=\"true\"></i> My account</a></li>\n                <li><a href=\"#\"><i class=\"fa fa-envelope-o fw\"></i> My inbox</a></li>\n                <li><a href=\"#\"><i class=\"fa fa-question-circle-o fw\"></i> Help</a></li>\n                <li role=\"separator\" class=\"divider\"></li>\n                <li><a href=\"#\"><i class=\"fa fa-sign-out\"></i> Log out</a></li>\n              </ul>-->\n            </li>\n        </ul>\n      </div>\n\n  </div>\n  </header>\n"

/***/ }),

/***/ "./src/app/components/header/header.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _services_settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/settings.service */ "./src/app/services/settings.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(userService, settingsService, router) {
        this.userService = userService;
        this.settingsService = settingsService;
        this.router = router;
        this.currentUser = null;
        this.errorMessage = '';
        this.isLoading = true;
    }
    HeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.loggedInUser.subscribe(function (data) {
            _this.currentUser = data;
            _this.isLoading = false;
        });
    };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/components/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.scss */ "./src/app/components/header/header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"],
            _services_settings_service__WEBPACK_IMPORTED_MODULE_3__["SettingsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/services/interceptor.config.ts":
/*!************************************************!*\
  !*** ./src/app/services/interceptor.config.ts ***!
  \************************************************/
/*! exports provided: InterceptorConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InterceptorConfig", function() { return InterceptorConfig; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_user_impl_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/user.impl.service */ "./src/app/services/user.impl.service.ts");



var InterceptorConfig = /** @class */ (function () {
    function InterceptorConfig(user) {
        this.user = user;
    }
    InterceptorConfig.prototype.intercept = function (request, next) {
        if (request.method === 'POST' && this.user && this.user.getCurrentUser()) {
            console.log('from interceptor->', this.user.getCurrentUser().apiToken);
            request = request.clone({
                setHeaders: {
                    'X-Bonita-API-Token': "" + this.user.getCurrentUser().apiToken
                }
            });
        }
        return next.handle(request);
    };
    InterceptorConfig = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_user_impl_service__WEBPACK_IMPORTED_MODULE_2__["UserImpl"]])
    ], InterceptorConfig);
    return InterceptorConfig;
}());



/***/ }),

/***/ "./src/app/services/service.ts":
/*!*************************************!*\
  !*** ./src/app/services/service.ts ***!
  \*************************************/
/*! exports provided: Service, mapStatusLookups */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Service", function() { return Service; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mapStatusLookups", function() { return mapStatusLookups; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var Service = /** @class */ (function () {
    function Service() {
    }
    Service.prototype.getGetHeaders = function () {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        headers.append('Accept', 'application/json');
        return headers;
    };
    Service.prototype.getUrlHeaders = function () {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        return headers;
    };
    Service.prototype.getPostHeaders = function (userService) {
        var headers = this.getGetHeaders();
        headers.append('X-Bonita-API-Token', userService.getCurrentUser().apiToken);
        return headers;
    };
    Service = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
    ], Service);
    return Service;
}());

function mapStatusLookups(response) {
    return response.json().map(toStatusLookup);
}
function toStatusLookup(r) {
    var statusLookup = ({
        processInstanceId: r.processInstanceId,
        humanTaskStatus: r.humanTaskStatus,
        documents: r.documents.map(toDocument)
    });
    return statusLookup;
}
function toDocument(r) {
    var document = ({
        filename: r.filename,
        description: r.description,
        docId: r.docId
    });
    return document;
}


/***/ }),

/***/ "./src/app/services/settings.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/settings.service.ts ***!
  \**********************************************/
/*! exports provided: SettingsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsService", function() { return SettingsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ngx_webstorage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-webstorage-service */ "./node_modules/ngx-webstorage-service/fesm5/ngx-webstorage-service.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");






// import uiLabels from '../../assets/ui-labels.json';
var SettingsService = /** @class */ (function () {
    function SettingsService(storage, sessionStorage, http) {
        this.storage = storage;
        this.sessionStorage = sessionStorage;
        this.http = http;
        this._jsonURL = 'assets/ui-labels.json';
    }
    SettingsService.prototype.getBonitaApiBaseUrl = function () {
        // if (!this.bonitaApiBaseUrl && window && window.location) {
        //    const paths = window.location.pathname.split('/', 2);
        //    this.bonitaApiBaseUrl = window.location.origin + '/';
        //    if (paths && paths.length > 1) {
        //      this.bonitaApiBaseUrl += paths[1] ;
        //      this.bonitaApiBaseUrl += 'bonita/' ;
        //    }
        //    this.bonitaApiBaseUrl += 'API' ;
        // }
        // return this.bonitaApiBaseUrl ;
        return 'http://localhost:8080/bonita/API';
        // return 'http://localhost:9990' ;
    };
    SettingsService.prototype.getBonitaBaseUrl = function () {
        if (!this.bonitaBaseUrl && window && window.location) {
            var paths = window.location.pathname.split('/', 2);
            this.bonitaBaseUrl = '/';
            if (paths && paths.length > 1) {
                this.bonitaBaseUrl += paths[1];
            }
        }
        return this.bonitaBaseUrl;
    };
    SettingsService.prototype.getUiLabels = function () {
        if (!this.labels) {
            //   this.labels = this.getJSON();
        }
        return this.labels;
    };
    SettingsService.prototype.getJSON = function () {
        return this.http.get(this._jsonURL)
            .map(function (response) {
            response.json();
        });
    };
    SettingsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(ngx_webstorage_service__WEBPACK_IMPORTED_MODULE_3__["LOCAL_STORAGE"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(ngx_webstorage_service__WEBPACK_IMPORTED_MODULE_3__["SESSION_STORAGE"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, Object, _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], SettingsService);
    return SettingsService;
}());



/***/ }),

/***/ "./src/app/services/user.impl.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/user.impl.service.ts ***!
  \***********************************************/
/*! exports provided: UserImpl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserImpl", function() { return UserImpl; });
var UserImpl = /** @class */ (function () {
    function UserImpl() {
    }
    UserImpl.prototype.getName = function () {
        var name = null;
        if (this.firstname && this.firstname.length > 0) {
            name = this.firstname;
        }
        if (this.lastname && this.lastname.length > 0) {
            if (name) {
                name = name + ' ' + this.lastname;
            }
            else {
                name = this.lastname;
            }
        }
        if (!name || name.length === 0) {
            name = this.username;
        }
        return name;
    };
    UserImpl.prototype.setPermissions = function (permissions) {
        this.permissions = permissions;
    };
    UserImpl.prototype.getAuthorizationToken = function () {
        return this.apiToken;
    };
    UserImpl.prototype.setAuthorizationToken = function (token) {
        this.apiToken = token;
    };
    UserImpl.prototype.setCurrentUser = function (cUser) {
        this.currentUser = cUser;
    };
    UserImpl.prototype.getCurrentUser = function () {
        return this.currentUser;
    };
    return UserImpl;
}());



/***/ }),

/***/ "./src/app/services/user.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/user.service.ts ***!
  \******************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings.service */ "./src/app/services/settings.service.ts");
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./service */ "./src/app/services/service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_observable_throw__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/add/observable/throw */ "./node_modules/rxjs-compat/_esm5/add/observable/throw.js");
/* harmony import */ var _user_impl_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./user.impl.service */ "./src/app/services/user.impl.service.ts");










function mapUserList(response) {
    return response.json().map(toUser);
}
function toUser(r) {
    var user = new _user_impl_service__WEBPACK_IMPORTED_MODULE_9__["UserImpl"]();
    user.id = r.user_id;
    user.username = r.user_name;
    console.log('token => ', r.headers.get('X-Bonita-API-Token'));
    user.setAuthorizationToken(r.headers.get('X-Bonita-API-Token'));
    user.setCurrentUser(r);
    // user.firstname = r.firstname;
    // user.lastname = r.lastname;
    if (r.professional_data) {
        user.email = r.professional_data.email;
    }
    return user;
}
function mapCurrentUser(response) {
    console.log('currentUser');
    var currentUser = toCurrentUser(response);
    currentUser.apiToken = response.headers.get('X-Bonita-API-Token');
    return currentUser;
}
function handleError(err) {
    var errorMessage = '';
    if (err.error instanceof ErrorEvent) {
        errorMessage = "An error occurred: " + err.error.message;
    }
    else {
        errorMessage = "Server returned code: " + err.status + ", error message is: " + err.message;
    }
    // console.log(errorMessage);
    return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["throwError"])(errorMessage);
}
function toCurrentUser(r) {
    var user = new _user_impl_service__WEBPACK_IMPORTED_MODULE_9__["UserImpl"]();
    user.id = r.user_id;
    user.username = r.user_name;
    user.sessionId = r.session_id;
    return user;
}
var UserService = /** @class */ (function (_super) {
    tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"](UserService, _super);
    function UserService(http, settingsService) {
        var _this = _super.call(this) || this;
        _this.http = http;
        _this.settingsService = settingsService;
        _this.loggedInUser = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        var currentUser = _this.http
            .get(
        //  `${this.settingsService.getBonitaApiBaseUrl()}/loginService`,
        _this.settingsService.getBonitaApiBaseUrl() + "/system/session/unusedId", { headers: _this.getGetHeaders() })
            .map(mapCurrentUser)
            .catch(handleError);
        currentUser.subscribe(function (currentLoggedInUser) {
            // TODO: Fetching all users (c=-1) -- this is perhaps dangerous and should either grab a huge number or iterate over pages
            _this.http
                .get(_this.settingsService.getBonitaApiBaseUrl() + "/identity/user/?p=0&c=-1&d=professional_data", { headers: _this.getGetHeaders() })
                .map(mapUserList)
                .subscribe(function (userList) {
                _this.userList = new Map();
                _this.usernameList = new Map();
                for (var _i = 0, userList_1 = userList; _i < userList_1.length; _i++) {
                    var user = userList_1[_i];
                    _this.userList.set(user.id, user);
                    _this.usernameList.set(user.username, user);
                }
                _this.currentUser.apiToken = currentLoggedInUser.apiToken;
            });
        });
        return _this;
    }
    UserService.prototype.getCurrentUser = function () {
        return this.currentUser;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], UserService.prototype, "loggedInUser", void 0);
    UserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _settings_service__WEBPACK_IMPORTED_MODULE_3__["SettingsService"]])
    ], UserService);
    return UserService;
}(_service__WEBPACK_IMPORTED_MODULE_4__["Service"]));



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\work\crisil\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map